/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package observer.interfaces;

/**
 *
 * @author gabri
 */
public interface Observer {
    void  update();
    public void setSubject(Subject subject);
}
